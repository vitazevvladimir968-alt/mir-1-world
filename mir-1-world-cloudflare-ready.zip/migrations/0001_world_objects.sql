CREATE TABLE IF NOT EXISTS world_objects (
  id TEXT PRIMARY KEY,
  x INTEGER NOT NULL,
  y INTEGER NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('house','tower','tree','monument')),
  createdAt TEXT NOT NULL,
  UNIQUE(x, y)
);
