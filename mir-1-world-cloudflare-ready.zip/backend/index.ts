import { router, json, error, db } from '@appdeploy/sdk';

type ObjectType = 'house' | 'tower' | 'tree' | 'monument';
type WorldObject = {
  id: string;
  x: number;
  y: number;
  name: string;
  type: ObjectType;
  createdAt: string;
};

const allowedTypes = new Set<ObjectType>([
  'house',
  'tower',
  'tree',
  'monument',
]);
const TABLE = 'world_objects';

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],

  'GET /api/world': [
    async () => {
      const result = await db.list<WorldObject>(TABLE, { limit: 100 });
      return json({ objects: result.items });
    },
  ],

  'POST /api/world/build': [
    async ({ body }) => {
      if (!body || typeof body !== 'object') {
        return error('invalid_body', 400);
      }

      const input = body as {
        name?: unknown;
        type?: unknown;
        x?: unknown;
        y?: unknown;
      };
      const name =
        typeof input.name === 'string' ? input.name.trim().slice(0, 20) : '';
      const x = input.x;
      const y = input.y;
      const type = input.type;

      if (name.length < 1) return error('name_required', 400);
      if (
        typeof x !== 'number' ||
        !Number.isInteger(x) ||
        x < 0 ||
        x > 7 ||
        typeof y !== 'number' ||
        !Number.isInteger(y) ||
        y < 0 ||
        y > 7
      ) {
        return error('invalid_cell', 400);
      }
      if (typeof type !== 'string' || !allowedTypes.has(type as ObjectType)) {
        return error('invalid_object_type', 400);
      }

      const id = `cell_${x}_${y}`;
      const object: WorldObject = {
        id,
        x,
        y,
        name,
        type: type as ObjectType,
        createdAt: new Date().toISOString(),
      };

      const [createdId] = await db.tx.add(TABLE, [{ ...object, id }]);
      if (!createdId) return error('cell_occupied', 409);
      return json({ object });
    },
  ],
});
