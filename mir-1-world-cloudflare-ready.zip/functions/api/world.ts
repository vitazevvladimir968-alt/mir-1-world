interface Env { DB: D1Database }
interface WorldObject { id: string; x: number; y: number; name: string; type: 'house'|'tower'|'tree'|'monument'; createdAt: string }
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
export const onRequestGet: PagesFunction<Env> = async ({ env }) => {
  const result = await env.DB.prepare('SELECT id,x,y,name,type,createdAt FROM world_objects ORDER BY createdAt ASC LIMIT 1000').all<WorldObject>();
  return json({ objects: result.results || [] });
};
export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  let input: any;
  try { input = await request.json(); } catch { return json({ error: 'invalid_body' }, 400); }
  const name = typeof input?.name === 'string' ? input.name.trim().slice(0,20) : '';
  const { x, y, type } = input || {};
  if (!name) return json({ error: 'name_required' }, 400);
  if (!Number.isInteger(x) || x < -10 || x > 10 || !Number.isInteger(y) || y < -10 || y > 10) return json({ error: 'invalid_cell' }, 400);
  if (!['house','tower','tree','monument'].includes(type)) return json({ error: 'invalid_object_type' }, 400);
  const id = `cell_${x}_${y}`;
  const object: WorldObject = { id, x, y, name, type, createdAt: new Date().toISOString() };
  try {
    await env.DB.prepare('INSERT INTO world_objects (id,x,y,name,type,createdAt) VALUES (?1,?2,?3,?4,?5,?6)').bind(id,x,y,name,type,object.createdAt).run();
  } catch {
    return json({ error: 'cell_occupied' }, 409);
  }
  return json({ object }, 201);
};
