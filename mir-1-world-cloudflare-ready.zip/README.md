# МИР № 1 — Cloudflare Pages

## Deployment
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: `/`

## Shared world database (required for multiplayer)
1. In Cloudflare Dashboard, create a D1 database named `mir-1-world-db`.
2. In D1 Console, run the SQL from `migrations/0001_world_objects.sql`.
3. In the Pages project, open Settings → Functions → D1 database bindings and bind variable `DB` to `mir-1-world-db`.
4. Redeploy the Pages project after adding the binding.

API routes:
- `GET /api/world`
- `POST /api/world/build`

The frontend no longer imports the AppDeploy SDK. Keep the original AppDeploy app until the Cloudflare deployment and shared database have been tested. The build was not verified in this environment because dependency installation timed out.
